﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO.Ports;

namespace COM_select
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        int intlen = 0;

        private void PbConnect_Click(object sender, EventArgs e)
        {
            if (LbStatus.Text == "Disconnected")
            {
                COM.PortName = CbSecCom.Text;
                COM.Open();
                if (COM.IsOpen) LbStatus.Text = "Connected";
                PbConnect.Text = "Disconnect";
                PbSend.Enabled = true;
                PbSendTime.Enabled = true;
                PbLoop.Enabled = true;
              //  timer3.Enabled = true;
            }
            else
            {
                COM.Close();
                LbStatus.Text = "Disconnected";
                PbConnect.Text = "Connect";
                PbSend.Enabled = false;
                PbSendTime.Enabled = false;
                PbLoop.Enabled = false;
               // timer3.Enabled = false;
            }
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            txtTime.Text = DateTime.Now.ToString();
            string[] ports = SerialPort.GetPortNames();
            if (intlen != ports.Length)
            {
                intlen = ports.Length;
                CbSecCom.Items.Clear();
                for (int j = 0; j < intlen; j++)
                {
                    CbSecCom.Items.Add(ports[j]);
                }
                CbSecCom.Text = ports[0];
            }
        }

        /*     private void timer3_Tick(object sender, EventArgs e)
             {
                 string s;
                 s = COM.ReadLine();
                 txtReceive.Items.Add(s);  
             } */

        private void COM_DataReceived(object sender, SerialDataReceivedEventArgs e)
        {
            string s;
            s = COM.ReadLine();
            Display(s);
        }
        private delegate void DIDisplay(string s);
        private void Display (string s)
        {
                if (TxtReceive.InvokeRequired)
                {
                    DIDisplay sd = new DIDisplay(Display);
                    TxtReceive.Invoke(sd, new object[] {s});
                }
                else
                {
                    TxtReceive.Items.Add(s);
                    TxtFReceive.Text = s;
                }
         }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void PbSend_Click(object sender, EventArgs e)
        {
            string s;
            if (LbStatus.Text == "Connected")
            {
                s = TxtSend.Text;
                COM.WriteLine(s);
            }
        }
        private void PbSendTime_Click(object sender, EventArgs e)
        {
            string s, t;
            if (LbStatus.Text == "Connected")
            {
                t = DateTime.Now.DayOfWeek.ToString();
                switch (t)
                {
                    case "Monday": s = "2";
                        break;
                    case "Tuesday": s = "3";
                        break;
                    case "Wednesday": s = "4";
                        break;
                    case "Thursday": s = "5";
                        break;
                    case "Friday": s = "6";
                        break;
                    case "Saturday": s = "7";
                        break;
                    default: s = "0";
                        break;
                }
                s = s + " " + (DateTime.Now.Day / 10).ToString() + (DateTime.Now.Day % 10).ToString();
                s = s + "/" + (DateTime.Now.Month / 10).ToString() + (DateTime.Now.Month % 10).ToString();
                s = s + "/" + "20" + ((DateTime.Now.Year /10) % 10).ToString() + (DateTime.Now.Year % 10).ToString();
                s = s + " " + (DateTime.Now.Hour / 10).ToString() + (DateTime.Now.Hour % 10).ToString();
                s = s + ":" + (DateTime.Now.Minute / 10).ToString() + (DateTime.Now.Minute % 10).ToString();
                s = s + ":" + (DateTime.Now.Second / 10).ToString() + (DateTime.Now.Second % 10).ToString();
                TxtSend.Text = s;
                COM.WriteLine(s);
            }
        }
        private void PbClearR_Click(object sender, EventArgs e)
        {
            TxtReceive.Items.Clear();
        }

        private void PbClearS_Click(object sender, EventArgs e)
        {
            TxtSend.Text = "";
        }

        private void Pbexit_Click(object sender, EventArgs e)
        {
            Close();
        }
        private void PbLoop_Click(object sender, EventArgs e)
        {
            if (PbLoop.Text == "Loop 1s")
            {
                timer2.Enabled = true;
                PbSend.Enabled = false;
                PbSendTime.Enabled = false;
                PbLoop.Text = "Stop";
            }
            else
            {
                timer2.Enabled = false;
                PbSend.Enabled = true;
                PbSendTime.Enabled = true;
                PbLoop.Text = "Loop 1s";
            }
        }

        private void timer2_Tick(object sender, EventArgs e)
        {
            PbSend_Click(sender, e);
        }
    }
}
