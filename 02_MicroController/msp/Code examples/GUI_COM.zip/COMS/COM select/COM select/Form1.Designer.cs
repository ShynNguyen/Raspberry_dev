﻿namespace COM_select
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.COM = new System.IO.Ports.SerialPort(this.components);
            this.LbStatus = new System.Windows.Forms.Label();
            this.PbConnect = new System.Windows.Forms.Button();
            this.CbSecCom = new System.Windows.Forms.ComboBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.txtTime = new System.Windows.Forms.TextBox();
            this.PbSend = new System.Windows.Forms.Button();
            this.TxtSend = new System.Windows.Forms.TextBox();
            this.TxtReceive = new System.Windows.Forms.ListBox();
            this.PbClearS = new System.Windows.Forms.Button();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.TxtFReceive = new System.Windows.Forms.TextBox();
            this.Pbexit = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.PbClearR = new System.Windows.Forms.Button();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.PbLoop = new System.Windows.Forms.Button();
            this.PbSendTime = new System.Windows.Forms.Button();
            this.timer2 = new System.Windows.Forms.Timer(this.components);
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.groupBox3.SuspendLayout();
            this.SuspendLayout();
            // 
            // timer1
            // 
            this.timer1.Enabled = true;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // COM
            // 
            this.COM.BaudRate = 19200;
            this.COM.DataReceived += new System.IO.Ports.SerialDataReceivedEventHandler(this.COM_DataReceived);
            // 
            // LbStatus
            // 
            this.LbStatus.AutoSize = true;
            this.LbStatus.Font = new System.Drawing.Font("Microsoft Sans Serif", 12.22642F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LbStatus.Location = new System.Drawing.Point(176, 83);
            this.LbStatus.Name = "LbStatus";
            this.LbStatus.Size = new System.Drawing.Size(138, 24);
            this.LbStatus.TabIndex = 0;
            this.LbStatus.Text = "Disconnected";
            // 
            // PbConnect
            // 
            this.PbConnect.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.150944F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.PbConnect.Location = new System.Drawing.Point(193, 27);
            this.PbConnect.Name = "PbConnect";
            this.PbConnect.Size = new System.Drawing.Size(110, 34);
            this.PbConnect.TabIndex = 1;
            this.PbConnect.Text = "Connect";
            this.PbConnect.UseVisualStyleBackColor = true;
            this.PbConnect.Click += new System.EventHandler(this.PbConnect_Click);
            // 
            // CbSecCom
            // 
            this.CbSecCom.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.150944F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CbSecCom.FormattingEnabled = true;
            this.CbSecCom.Location = new System.Drawing.Point(16, 84);
            this.CbSecCom.Name = "CbSecCom";
            this.CbSecCom.Size = new System.Drawing.Size(141, 23);
            this.CbSecCom.TabIndex = 2;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.txtTime);
            this.groupBox1.Controls.Add(this.CbSecCom);
            this.groupBox1.Controls.Add(this.PbConnect);
            this.groupBox1.Controls.Add(this.LbStatus);
            this.groupBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.150944F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.Location = new System.Drawing.Point(12, 19);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(320, 138);
            this.groupBox1.TabIndex = 6;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "COM Select";
            // 
            // txtTime
            // 
            this.txtTime.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.150944F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtTime.Location = new System.Drawing.Point(16, 34);
            this.txtTime.Name = "txtTime";
            this.txtTime.ReadOnly = true;
            this.txtTime.Size = new System.Drawing.Size(141, 21);
            this.txtTime.TabIndex = 8;
            // 
            // PbSend
            // 
            this.PbSend.Enabled = false;
            this.PbSend.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.150944F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.PbSend.Location = new System.Drawing.Point(6, 89);
            this.PbSend.Name = "PbSend";
            this.PbSend.Size = new System.Drawing.Size(67, 41);
            this.PbSend.TabIndex = 5;
            this.PbSend.Text = "Send";
            this.PbSend.UseVisualStyleBackColor = true;
            this.PbSend.Click += new System.EventHandler(this.PbSend_Click);
            // 
            // TxtSend
            // 
            this.TxtSend.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.18868F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TxtSend.Location = new System.Drawing.Point(6, 19);
            this.TxtSend.Multiline = true;
            this.TxtSend.Name = "TxtSend";
            this.TxtSend.Size = new System.Drawing.Size(413, 59);
            this.TxtSend.TabIndex = 4;
            // 
            // TxtReceive
            // 
            this.TxtReceive.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.830189F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TxtReceive.FormattingEnabled = true;
            this.TxtReceive.ItemHeight = 16;
            this.TxtReceive.Location = new System.Drawing.Point(6, 59);
            this.TxtReceive.Name = "TxtReceive";
            this.TxtReceive.Size = new System.Drawing.Size(570, 260);
            this.TxtReceive.TabIndex = 6;
            // 
            // PbClearS
            // 
            this.PbClearS.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.150944F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.PbClearS.Location = new System.Drawing.Point(345, 89);
            this.PbClearS.Name = "PbClearS";
            this.PbClearS.Size = new System.Drawing.Size(67, 41);
            this.PbClearS.TabIndex = 7;
            this.PbClearS.Text = "Clear";
            this.PbClearS.UseVisualStyleBackColor = true;
            this.PbClearS.Click += new System.EventHandler(this.PbClearS_Click);
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.TxtFReceive);
            this.groupBox2.Controls.Add(this.Pbexit);
            this.groupBox2.Controls.Add(this.pictureBox1);
            this.groupBox2.Controls.Add(this.PbClearR);
            this.groupBox2.Controls.Add(this.TxtReceive);
            this.groupBox2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.150944F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox2.Location = new System.Drawing.Point(12, 163);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(751, 325);
            this.groupBox2.TabIndex = 8;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Receive";
            // 
            // TxtFReceive
            // 
            this.TxtFReceive.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.18868F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TxtFReceive.Location = new System.Drawing.Point(6, 20);
            this.TxtFReceive.Name = "TxtFReceive";
            this.TxtFReceive.ReadOnly = true;
            this.TxtFReceive.Size = new System.Drawing.Size(570, 24);
            this.TxtFReceive.TabIndex = 10;
            // 
            // Pbexit
            // 
            this.Pbexit.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.150944F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Pbexit.Location = new System.Drawing.Point(637, 261);
            this.Pbexit.Name = "Pbexit";
            this.Pbexit.Size = new System.Drawing.Size(67, 42);
            this.Pbexit.TabIndex = 9;
            this.Pbexit.Text = "Exit";
            this.Pbexit.UseVisualStyleBackColor = true;
            this.Pbexit.Click += new System.EventHandler(this.Pbexit_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.InitialImage = ((System.Drawing.Image)(resources.GetObject("pictureBox1.InitialImage")));
            this.pictureBox1.Location = new System.Drawing.Point(601, 120);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(137, 111);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 7;
            this.pictureBox1.TabStop = false;
            // 
            // PbClearR
            // 
            this.PbClearR.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.150944F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.PbClearR.Location = new System.Drawing.Point(601, 36);
            this.PbClearR.Name = "PbClearR";
            this.PbClearR.Size = new System.Drawing.Size(137, 42);
            this.PbClearR.TabIndex = 8;
            this.PbClearR.Text = "Clear List";
            this.PbClearR.UseVisualStyleBackColor = true;
            this.PbClearR.Click += new System.EventHandler(this.PbClearR_Click);
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.PbLoop);
            this.groupBox3.Controls.Add(this.PbSendTime);
            this.groupBox3.Controls.Add(this.PbClearS);
            this.groupBox3.Controls.Add(this.TxtSend);
            this.groupBox3.Controls.Add(this.PbSend);
            this.groupBox3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.150944F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox3.Location = new System.Drawing.Point(338, 19);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(425, 138);
            this.groupBox3.TabIndex = 9;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Send";
            // 
            // PbLoop
            // 
            this.PbLoop.Enabled = false;
            this.PbLoop.Location = new System.Drawing.Point(98, 89);
            this.PbLoop.Name = "PbLoop";
            this.PbLoop.Size = new System.Drawing.Size(100, 41);
            this.PbLoop.TabIndex = 11;
            this.PbLoop.Text = "Loop 1s";
            this.PbLoop.UseVisualStyleBackColor = true;
            this.PbLoop.Click += new System.EventHandler(this.PbLoop_Click);
            // 
            // PbSendTime
            // 
            this.PbSendTime.Enabled = false;
            this.PbSendTime.Location = new System.Drawing.Point(224, 89);
            this.PbSendTime.Name = "PbSendTime";
            this.PbSendTime.Size = new System.Drawing.Size(99, 41);
            this.PbSendTime.TabIndex = 10;
            this.PbSendTime.Text = "Send Time";
            this.PbSendTime.UseVisualStyleBackColor = true;
            this.PbSendTime.Click += new System.EventHandler(this.PbSendTime_Click);
            // 
            // timer2
            // 
            this.timer2.Interval = 1000;
            this.timer2.Tick += new System.EventHandler(this.timer2_Tick);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(770, 500);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.MaximizeBox = false;
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Timer timer1;
        private System.IO.Ports.SerialPort COM;
        private System.Windows.Forms.Label LbStatus;
        private System.Windows.Forms.Button PbConnect;
        private System.Windows.Forms.ComboBox CbSecCom;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TextBox txtTime;
        private System.Windows.Forms.Button PbSend;
        private System.Windows.Forms.TextBox TxtSend;
        private System.Windows.Forms.ListBox TxtReceive;
        private System.Windows.Forms.Button PbClearS;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Button Pbexit;
        private System.Windows.Forms.Button PbClearR;
        private System.Windows.Forms.Button PbSendTime;
        private System.Windows.Forms.TextBox TxtFReceive;
        private System.Windows.Forms.Button PbLoop;
        private System.Windows.Forms.Timer timer2;
    }
}

